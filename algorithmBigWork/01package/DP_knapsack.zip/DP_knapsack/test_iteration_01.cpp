#include <iostream>
#include "iteration.cpp"

using namespace std;

int main(){

    //KNAPSACK_01 iteration test
    display(iteration, KNAPSACK_01);
    for(file_index = 1; file_index < 9; file_index++){
        Init_all();
        Init_f();
        Read_data_01(KNAPSACK_01, file_index);
        start_time = clock();
        Knapsack();
        Traceback();
        end_time = clock();
        display_results(iteration, KNAPSACK_01);
    }

}