#include <iostream>
#include "iteration.cpp"

using namespace std;

int main(){

    display(iteration, KNAPSACK_02_large);
    for(file_index = 1; file_index < 22; file_index++){
        Init_all();
        Init_f();
        Read_data_02(KNAPSACK_02_large, file_index);
        start_time = clock();
        Knapsack();
        Traceback();
        end_time = clock();
        display_results(iteration, KNAPSACK_02_large);
    }

    return 0;
}