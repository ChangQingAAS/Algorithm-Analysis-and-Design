/**
 * 背包问题全局变量，宏，以及一些常用函数
 */

#ifndef _READ_DATA_H_
#define _READ_DATA_H_

#include <iomanip>
using namespace std;

#define MAX 0xffff
#define long_d long long

#define recursion 0x10
#define iteration 0x20

typedef int method_type;

int n;
long_d c;
long_d p[MAX];
long_d w[MAX];
long_d s[MAX];
long_d optimum[100];
int file_count = 0;

int res[MAX];
long_d res_optimum[100];

int file_index = 0;

clock_t start_time;
clock_t end_time;

int total_recurse_time = 0;

bool compare_results(file_dir d);

void Init_all(){
    for(int i = 0; i < MAX; i++){
        p[i] = 0;
        w[i] = 0;
        s[i] = 0;
        res[i] = 0;
    }
}

void display(method_type t, file_dir d){
    cout << "--------" << (d == KNAPSACK_01 ? "KNAPSACK_01" : "KNAPSACK_02");
    cout << "--------" << (t == recursion ? "recursion" : "iteration"); 
    cout <<"--------------\n";
    cout << "FileIndex\t" << " Answer   \t" << "TimeSpent";
    if(t == recursion) cout << "\tTotalRecurseTime\n";
    else cout << "\n";
}
void display_results(method_type t, file_dir d){
    cout << "    " << file_index << "   \t";

    if(compare_results(d)) cout << "Correct  \t";
    else cout << "Wrong    \t";

    double spent_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    cout << fixed << setprecision(2) << " " << spent_time * 1000 << "ms";
    if(t == recursion) cout << "          " << total_recurse_time << "\n";
    else cout << '\n';
}

bool compare_results(file_dir d){
    if(d == KNAPSACK_01 || d == KNAPSACK_02_large){
        for(int i = 1; i < n; i++)
            if(res[i] != s[i]) return false;
        return true;
    }
    else if(d == KNAPSACK_02_low){
        if(optimum[file_index] == res_optimum[file_index]) return true;
        return false;
    }
    return false;
}

#endif