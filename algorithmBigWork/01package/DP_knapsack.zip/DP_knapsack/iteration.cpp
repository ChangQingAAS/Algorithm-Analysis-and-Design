/**
 * 动态规划-0/1背包问题 迭代实现
 */

#ifndef _KNAPSACK_H_
#define _KNAPSACK_H_
#include <iostream>
#include "read_data.cpp"
using namespace std;
#define max_number 6500000
long_d f[50][max_number];
void Knapsack();
void Traceback();
void Init_f();

void Init_f(){
    for(int i = 0; i < 50; i++){
        for(int j = 0; j < 700000; j++){
            f[i][j] = 0;
        }
    }
}

void Knapsack(){

    int yMax = min(w[n] - 1, c);
    /* y < w[n]， f(n, y) = 0 */
    for(int y = 0; y <= yMax; y++) f[n][y] = 0;
    /* y >= w[n], f(n, y) = 1 */
    for(int y = w[n]; y <= c; y++) f[n][y] = p[n];

    for(int i = n - 1; i > 1; i--){
        yMax = min(w[i] - 1, c);
        for(int y = 0; y <= yMax; y++){
            /* y < w[i], f(i, y) = f(i + 1, y) */ 
            f[i][y] = f[i + 1][y];
        }
        for(int y = w[i]; y <= c; y++){
            /* y >= w[i], f(i, y) = max(f(i + 1, y), f(i + 1, y - w[i]) + p[i]) */ 
            f[i][y] = max(f[i + 1][y], f[i + 1][y - w[i]] + p[i]);
        }
    }
    /* there is no need to calculate f[1][0 -> c-1] */
    if(c >= w[1]) f[1][c] = max(f[2][c], f[2][c - w[1]] + p[1]);
    else f[1][c] = f[2][c];

    res_optimum[file_index] = f[1][c];
}

void Traceback(){
    
    int y = c;
    for(int i = 1; i < n; i++){
        if(f[i][y] == f[i + 1][y]) res[i] = 0;
        else{
            res[i] = 1;
            y -= w[i];
        }
    }
    res[n] = (f[n][c]) ? 1 : 0;
}


#endif