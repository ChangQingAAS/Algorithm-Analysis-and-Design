#include <iostream>
#include "recursion.cpp"

using namespace std;

int main(){

    display(recursion, KNAPSACK_02_low);
    for(file_index = 1; file_index < 11; file_index++){
        Init_all();
        total_recurse_time = 0;
        Read_data_03(KNAPSACK_02_low, file_index);
        start_time = clock();
        result();
        end_time = clock();
        display_results(recursion, KNAPSACK_02_low);
    }

    return 0;
}