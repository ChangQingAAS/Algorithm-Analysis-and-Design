#include <iostream>
#include "iteration.cpp"

using namespace std;

int main(){

    display(iteration, KNAPSACK_02_low);
    for(file_index = 1; file_index < 11; file_index++){
        Init_all();
        Init_f();
        Read_data_03(KNAPSACK_02_low, file_index);
        start_time = clock();
        Knapsack();
        Traceback();
        end_time = clock();
        display_results(iteration, KNAPSACK_02_low);
    }

    return 0;
}