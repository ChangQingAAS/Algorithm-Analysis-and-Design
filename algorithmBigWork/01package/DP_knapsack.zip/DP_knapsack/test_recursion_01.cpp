#include <iostream>
#include "recursion.cpp"

using namespace std;

int main(){

    //KNAPSACK_01 recursion test
    display(recursion, KNAPSACK_01);
    for(file_index = 1; file_index < 9; file_index++){
        Init_all();
        total_recurse_time = 0;
        Read_data_01(KNAPSACK_01, file_index);
        start_time = clock();
        result();
        end_time = clock();
        display_results(recursion, KNAPSACK_01);
    }

}